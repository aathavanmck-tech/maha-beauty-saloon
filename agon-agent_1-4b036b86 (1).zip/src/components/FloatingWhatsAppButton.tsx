import React from 'react';
import { MessageCircle } from 'lucide-react';
import { buildWhatsAppUrl, OFFICIAL_WHATSAPP_DISPLAY } from '../config/siteConfig';
import { BRAND_INFO } from '../data/salonData';

export const FloatingWhatsAppButton: React.FC = () => {
  const msg = [
    `Hello ${BRAND_INFO.businessName},`,
    `I would like to enquire about salon services / booking an appointment.`,
    `• Studio Locations: Hyderabad – Main Branch, Telangana / Chennai – Branch 2, Tamil Nadu`,
    `• Daily Operating Hours: 10 AM–8 PM`,
  ].join('\n');

  const directHref = buildWhatsAppUrl(msg);

  return (
    <a
      href={directHref}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={`Chat on WhatsApp with ${BRAND_INFO.businessName} (${OFFICIAL_WHATSAPP_DISPLAY})`}
      className="fixed z-40 safe-bottom-fab inline-flex items-center gap-2.5 pl-3.5 pr-4 py-3 min-h-[48px] rounded-full bg-[#4F101E] text-[#FAF7F2] border border-[#D4AF7A]/55 shadow-[0_12px_30px_rgba(44,6,15,0.42)] hover:bg-[#5F1123] active:scale-[0.98] transition-all"
    >
      <span className="w-7 h-7 rounded-full bg-[#25D366] text-white flex items-center justify-center shrink-0 shadow-xs">
        <MessageCircle className="w-4 h-4 fill-current" />
      </span>
      <span className="text-xs font-semibold tracking-wide whitespace-nowrap">
        WhatsApp Enquiry
      </span>
    </a>
  );
};
