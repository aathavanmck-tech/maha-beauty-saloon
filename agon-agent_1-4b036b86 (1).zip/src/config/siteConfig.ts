export const OFFICIAL_WHATSAPP_NUMBER = '919573590542';
export const OFFICIAL_WHATSAPP_DISPLAY = '+91 95735 90542';
export const OFFICIAL_WHATSAPP_BASE_URL = 'https://wa.me/919573590542';
export const OFFICIAL_INSTAGRAM_URL =
  'https://www.instagram.com/mahasalonaesthetic/';

export interface SiteExternalConfig {
  /**
   * Official salon WhatsApp number in international digits: 919573590542 (+91 95735 90542).
   */
  whatsappNumber: string;
  /**
   * Official Instagram profile URL.
   */
  instagramUrl: string;
  /**
   * Official Google Maps / Apple Maps URL for Hyderabad Main Branch.
   */
  hyderabadMapUrl: string;
  /**
   * Official Google Maps / Apple Maps URL for Chennai Branch 2.
   */
  chennaiMapUrl: string;
  /**
   * Official Google Business Profile / Google Reviews URL.
   */
  googleReviewsUrl: string;
}

const STORAGE_KEY = 'mahas_salon_external_config_v3';

export function sanitizeWhatsAppDigits(raw: string): string {
  return raw.replace(/[^\d]/g, '');
}

export const DEFAULT_SITE_CONFIG: SiteExternalConfig = {
  whatsappNumber:
    sanitizeWhatsAppDigits(
      (import.meta.env.VITE_WHATSAPP_NUMBER as string | undefined) || ''
    ) || OFFICIAL_WHATSAPP_NUMBER,
  instagramUrl:
    (import.meta.env.VITE_INSTAGRAM_URL as string | undefined)?.trim() ||
    OFFICIAL_INSTAGRAM_URL,
  hyderabadMapUrl:
    (import.meta.env.VITE_HYDERABAD_MAP_URL as string | undefined)?.trim() || '',
  chennaiMapUrl:
    (import.meta.env.VITE_CHENNAI_MAP_URL as string | undefined)?.trim() || '',
  googleReviewsUrl:
    (import.meta.env.VITE_GOOGLE_REVIEWS_URL as string | undefined)?.trim() || '',
};

export function loadSiteConfig(): SiteExternalConfig {
  if (typeof window === 'undefined') return DEFAULT_SITE_CONFIG;
  try {
    const raw = window.localStorage.getItem(STORAGE_KEY);
    if (!raw) return DEFAULT_SITE_CONFIG;
    const parsed = JSON.parse(raw) as Partial<SiteExternalConfig>;
    const cleanedWhatsapp = sanitizeWhatsAppDigits(parsed.whatsappNumber || '');
    return {
      whatsappNumber:
        cleanedWhatsapp.length >= 10
          ? cleanedWhatsapp
          : OFFICIAL_WHATSAPP_NUMBER,
      instagramUrl:
        typeof parsed.instagramUrl === 'string' && parsed.instagramUrl.trim()
          ? parsed.instagramUrl.trim()
          : OFFICIAL_INSTAGRAM_URL,
      hyderabadMapUrl:
        typeof parsed.hyderabadMapUrl === 'string'
          ? parsed.hyderabadMapUrl.trim()
          : DEFAULT_SITE_CONFIG.hyderabadMapUrl,
      chennaiMapUrl:
        typeof parsed.chennaiMapUrl === 'string'
          ? parsed.chennaiMapUrl.trim()
          : DEFAULT_SITE_CONFIG.chennaiMapUrl,
      googleReviewsUrl:
        typeof parsed.googleReviewsUrl === 'string'
          ? parsed.googleReviewsUrl.trim()
          : DEFAULT_SITE_CONFIG.googleReviewsUrl,
    };
  } catch {
    return DEFAULT_SITE_CONFIG;
  }
}

export function saveSiteConfig(config: SiteExternalConfig): void {
  if (typeof window === 'undefined') return;
  try {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(config));
  } catch {
    // Ignore storage quota errors
  }
}

/**
 * Builds the direct Click-to-Chat WhatsApp URL for +91 95735 90542:
 * Base: https://wa.me/919573590542
 * With pre-filled message: https://wa.me/919573590542?text=URL_ENCODED_MESSAGE
 * Never uses forwarding, sharing, or contact-selection endpoints.
 */
export function buildWhatsAppUrl(
  message?: string,
  whatsappNumber: string = OFFICIAL_WHATSAPP_NUMBER
): string {
  const cleanDigits =
    sanitizeWhatsAppDigits(whatsappNumber) || OFFICIAL_WHATSAPP_NUMBER;
  const base = `https://wa.me/${cleanDigits}`;
  if (!message || !message.trim()) {
    return base;
  }
  return `${base}?text=${encodeURIComponent(message.trim())}`;
}

/**
 * Opens a direct WhatsApp chat with +91 95735 90542 without any intermediate page.
 */
export function openDirectWhatsApp(
  message: string,
  whatsappNumber: string = OFFICIAL_WHATSAPP_NUMBER
): string {
  const url = buildWhatsAppUrl(message, whatsappNumber);
  if (typeof window !== 'undefined') {
    const win = window.open(url, '_blank', 'noopener,noreferrer');
    if (!win) {
      window.location.assign(url);
    }
  }
  return url;
}
